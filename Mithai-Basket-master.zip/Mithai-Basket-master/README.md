<h2 align="center">🛒 Mithai Basket 👨‍💻</h2>

## Project Deployed Link :
This project is live at : https://mithaibasket.onrender.com/

<p>Admin web pages video </p>

https://user-images.githubusercontent.com/85950488/211626510-7fb04f39-a91b-4e62-a461-9d77fe5f0e76.mp4


## Technologies Used 👨🏽‍💻:
1. ReactJs & Redux
2. Nodejs & Express
3. Mongodb Atlas(Database)
4. HTML , CSS , JavaScript
5. Material UI

## Installation 📦

> ./frontend -> npm install  
 ./backend  -> npm install
