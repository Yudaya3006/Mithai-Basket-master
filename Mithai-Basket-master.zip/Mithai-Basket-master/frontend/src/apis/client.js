const BASE_URL = process.env.REACT_APP_DOMAIN;

export { BASE_URL };
