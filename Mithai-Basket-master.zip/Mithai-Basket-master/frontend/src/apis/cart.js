const { BASE_URL } = require("./client");

const GET_CART = `${BASE_URL}/cart/`;
const UPDATE_CART = `${BASE_URL}/cart/update/`;

export {UPDATE_CART,GET_CART};