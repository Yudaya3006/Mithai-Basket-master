const { BASE_URL } = require("./client");

const REGISTER = BASE_URL+"/register";
const LOGIN = BASE_URL+"/login";

export {REGISTER , LOGIN};